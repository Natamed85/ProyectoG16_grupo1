<template>    
  <main>
    <section id="banner">
      <img src="https://i.ibb.co/PQVr5kV/consentido.gif" class="video-banner" />
    </section>
    <section id="bienvenidos">
      <h2>Lavado ecológico para tu auto</h2>
      <P
        >Somos una propuesta ecológica e innovadora de lavado de autos, nuestro
        principal objetivo es desarrollar una operación de calidad con la mayor
        comodidad de un servicio V.I.P. Trabajamos con personal altamente
        calificado y brindamos un servicio de spa para consentir y cuidar su
        auto con todas las medidas de seguridad para garantizar el cuidado de su
        vehículo. En ATILAVE encontrarás innovación, calidad y confort en el
        lavado ecológico de su auto en la ciudad de Bogotá.</P
      >
    </section>
    <section id="blog">
      <h3>Conoce nuestros servicios:</h3>
      <div class="contenedor">
        <article>
          <div class="servicio1">
            <img class="carro1" src="../assets/img/lavado carro1.png" />
            <aside>
              <h4>Servicio Express</h4>
              <p>
                Servicio de lavado exterior del vehículo con cera. Durante el
                proceso solo se utilizan insumos especializados y
                biodegradables.
              </p>
            </aside>
          </div>
          <div class="servicio2">
            <img class="carro2" src="../assets/img/lavado carro2.png" />
            <aside>
              <h4>Servicio ATILAVE MAX</h4>
              <p>
                Servicio de lavado exterior con cera e interior del vehículo. El
                procedimiento incluye aspirada, hidratación especializada de
                tableros y limpieza de carteras, con ambientador a petición del
                cliente.
              </p>
            </aside>
          </div>
          <div class="servicio3">
            <img class="carro3" src="../assets/img/lavado carro3.png" />
            <aside>
              <h4>Limpieza de motor</h4>
              <p>
                La limpieza del motor aporta al cuidado de esta pieza, evitando
                fallas posteriores que incidan en reparaciones de altos costos.
                Este servicio se realiza con especial cuidado y profesionalismo
                para prevenir daños en la estructura o fallas eléctricas.
                Realizarlo en un establecimiento serio y seguro es su garantía
                para mayor tranquilidad.
              </p>
            </aside>
          </div>
        </article>
      </div>
    </section>
    <section id="info">
      <h3>
        El desarrollo de nuestra operación está fundamentada en el cuidado del
        medio ambiente.
      </h3>
      <div class="contenedor">
        <div class="info-pet">
          <img src="../assets/img/icono1.png" alt="icono1" />
          <h4>
            Por esta razón nuestro modelo de lavado únicamente genera un consumo
            de 10 – 12 litros de agua por vehículo, a diferencia del sistema
            tradicional que puede generar un consumo de hasta 55 litros por
            carro.
          </h4>
        </div>
        <div class="info-pet">
          <img src="../assets/img/icono2.png" alt="icono2" />
          <h4>
            Usamos productos biodegradables que respetan el medio ambiente.
          </h4>
        </div>
        <div class="info-pet">
          <img src="../assets/img/icono3.png" alt="icono3" />
          <h4>
            Para mayor seguridad de nuestros clientes, el registro de cada
            vehículo se sistematiza incluyendo la toma de material fotográfico
            del estado del auto ya que nuestro mayor interés es garantizar el
            buen cuidado de su carro.
          </h4>
        </div>
        <div class="info-pet">
          <img src="../assets/img/icono4.png" alt="icono4" />
          <h4>
            Contamos con un equipo de supervisores que velan por la calidad del
            proceso y el cuidado de su auto.
          </h4>
        </div>
      </div>
    </section>
  </main>
</template>
<script>
export default {
  name: "Inicio",
  data() {
    return {
      msg: "Primera aplicacion con vue",
    };
  },
};
</script>

<style>
    @import url('../assets/css/estilos.css');
    @import url('../assets/css/menu.css');    
</style>

