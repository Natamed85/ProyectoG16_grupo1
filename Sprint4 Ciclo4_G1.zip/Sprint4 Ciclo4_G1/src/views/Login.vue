<template>    
        <form action="#" method="POST" autocomplete="off">
                <img src="https://i.ibb.co/N2jV8X9/trafico.gif" class="video-fondo">
                <div>
                    <div class="form-titulo">
                        <h2>Formulario de Login</h2>
                    </div>
                    <div class="contenedor-inputs">
                        <input type="text" placeholder="Ingrese su Usuario" class="form-control" name="txtusr" >
                        <input type="password" placeholder="Ingrese su Contraseña" class="form-control" name="txtpas">
                        <input type="submit" value="validar" id="BTNcontinuar" name="BTNcontinuar">
                        <p class="form-link">¿No tienes una cuenta? <a href="Registro">Ingresa aquí</a></p>
                    </div>
                </div>
            </form>    
</template>

<script>
export default {
name: "Formulario",
}
</script>

<style scoped>
    @import url('../assets/css/login.css');      
    @import url("https://kit.fontawesome.com/0366f095a1.js");
</style>