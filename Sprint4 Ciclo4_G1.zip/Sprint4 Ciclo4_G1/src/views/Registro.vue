<template> 
<div>         
        <FormulateForm action="#" method="post" class="form-register">
            <img src="https://i.ibb.co/N2jV8X9/trafico.gif" class="video-fondo">      
            <h2 class="form-titulo">CREA UNA CUENTA</h2>            
            <div class="contenedor-inputs">            
                <select id="tipo_documento" name="tipo_documento" class="input-30" style="height:48px" validation="required">
                    <option value="CC">CC - CÉDULA CIUDADANÍA</option>
                    <option value="CE">CE - CÉDULA EXTRANJERÍA</option>
                    <option value="PA">PA - PASAPORTE</option>
                    <option value="NIT">NIT</option>
                </select>
                <FormulateInput type="text" id="no_documento" name="no_documento" placeholder="Número Documento" class="input-48" validation="required"/>
                <FormulateInput type="text" id="nombres" name="nombres" placeholder="Nombres" class="input-48" validation="required"/>
                <FormulateInput type="text" id="apellidos" name="apellidos" placeholder="Apellidos" class="input-48" validation="required"/>
                <FormulateInput type="text" id="celular" name="celular" placeholder="Celular" class="input-48" validation="required"/>          
                <FormulateInput type="text" id="direccion" name="direccion" placeholder="Dirección" class="input-48" validation="required"/>
                <FormulateInput type="text" id="ciudad" name="ciudad" placeholder="Ciudad" class="input-48" validation="required"/>                
                <FormulateInput type="email" id="email" name="email" placeholder="Correo (será su Usuario)" class="input-48" validation="required|email"/>                
                <FormulateInput type="password" id="password" name="password" placeholder="Crear Contraseña" class="input-48" validation="required"/>
                <FormulateInput type="password" id="confirmapassword" name="confirmapassword" placeholder="Confirme la Contraseña" class="input-48" validation="required|confirm" validation-name="El password"/>
                <input type="submit" value="Registrar" class="btn-enviar" id="BTNcontinuar">
                <p class="form-link">¿Ya tienes una cuenta? <a href="login">Ingresa aquí</a></p>        
            </div>              
        </Formulateform>        
</div>

</template>

<script>
export default {
name: "Formulario",
}
</script>

<style>
    @import url('../assets/css/registro.css');
    @import url("https://kit.fontawesome.com/0366f095a1.js");   
</style>