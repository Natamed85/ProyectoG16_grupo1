<template>
  <Inicio />
</template>

<script>
// @ is an alias to /src
import Inicio from "./Inicio.vue";

export default {
  name: "Home",
  components: {
    Inicio,
  },
};
</script>
