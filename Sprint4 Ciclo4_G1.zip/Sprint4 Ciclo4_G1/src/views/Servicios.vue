<template>
<div>      
    <form action="registrar.php" method="post" class="form-tipoLavado">
        <img src="https://i.ibb.co/N2jV8X9/trafico.gif" class="video-fondo">
        <h2 class="form-titulo">Escoge el servicio: </h2>
        <div class="panel-body">        
            <input type="hidden" id="cod_tipo_lavado" name="cod_tipo_lavado" class="form-control">
            <label class="texto_sombra">Tipo de automotor:</label>
            <select id="tipo_automotor" name="tipo_automotor" class="form-control">
                <option value="Automóvil">Automóvil</option>
                <option value="Camioneta">Camioneta</option>
                <option value="Furgón">Furgón</option>
                <option value="Moto">Moto</option>
            </select>
            <label class="texto_sombra">Tipo de procedimiento:</label>
            <select id="tipo_procedimiento" name="tipo_procedimiento" class="form-control">
                <option value="Lavado general">Lavado general</option>
                <option value="Lavado general y desinfección">Lavado general y desinfección</option>
                <option value="Lavado general y aspirado">Lavado general y aspirado</option>
                <option value="Encerado">Encerado</option>
                <option value="Polichado">Polichado</option>
            </select>
            <label class="texto_sombra">Precio:</label>
            <input type="input" id="precio" name="precio" class="form-control">
            <label class="texto_sombra">Duración:</label>
            <input type="number" id="duracion" name="duracion" class="form-control">                              
            <input type="submit" value="Guardar" class="btn-enviar" id="BTNcontinuar">                    
        </div>    
    </form>                
</div>
</template>

<script>
export default {
name: "Servicios",
}
</script>

<style>
    @import url('../assets/css/servicios.css');
    @import url("https://kit.fontawesome.com/0366f095a1.js");  

</style>