<template>
<div> 
    <footer>
        <div class="contenedor">
            <p class="copy">ATILAVE &copy; 2021</p>
            <div class="sociales">
                <a class="twitter" href="#"></a>
                <a class="instagram" href="#"></a>
                <a><i class="fab fa-facebook" href="#"></i></a>
                <a><i class="fab fa-twitter" href="#"></i></a>
                <a><i class="fab fa-instagram" href="#"></i></a>
                <a><i class="fab fa-youtube" href="#"></i></a>                                       
            </div>
        </div>
    </footer>
</div>
</template>

<script>
export default {
    name: `Footer`
}
</script>
<style>
    @import url('../assets/css/estilos.css');
</style>