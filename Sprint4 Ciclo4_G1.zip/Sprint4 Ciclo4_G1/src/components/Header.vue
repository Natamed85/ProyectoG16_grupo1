<template>
  <div>
    <header>
      <div class="contenedor">
        <img class="logo" src="../assets/img/logo_white_large.png" />
        <input type="checkbox" id="menu-bar" />
        <label><font-awesome-icon icon="bars" for="menu-bar" /></label>
        <nav class="menu">
          <img src="../assets/img/logo_white_large.png" />
          <router-link to="Inicio">Inicio</router-link>
          <router-link to="Login">Login</router-link>
          <router-link to="Registro">Registro</router-link>
          <router-link to="Servicios">Servicios</router-link>
        </nav>
      </div>
    </header>
  </div>
</template>

<script>
export default {
  name: "Header",
};
</script>
