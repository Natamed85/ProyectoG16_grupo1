const express = require('express');
const app = express();
const bodyParser = require('body-parser');



//middlewares
app.use(bodyParser.json());

//Rutas
app.use(require('./src/routes/main.routes'));
app.use(require('./src/routes/persona.route'));
app.use(require('./src/routes/servicio.route'));



module.exports = app;
