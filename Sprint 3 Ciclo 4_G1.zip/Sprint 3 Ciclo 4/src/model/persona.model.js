const mongoose = require('mongoose');
const {Schema} = require('mongoose');
const bcrypt = require('bcrypt-nodejs');


let personSchema = new Schema ({
    tip_documento: String,
    num_documento: String,
    nombres: String,
    apellidos: String,
    celular: String,
    direccion: String,
    ciudad: String,
    email: String,
    password: String,   
    token:String 

},
{versionkey: false});

personSchema.methods.encryptPassword = (password)=>{
    return bcrypt.hashSync(password, bcrypt.genSaltSync(10));
};
personSchema.methods.comparePassword = function (password){
    return bcrypt.compareSync(password, this.password);
}

const Person = mongoose.model('Person', personSchema);

module.exports = Person;